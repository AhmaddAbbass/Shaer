# shaer_service

Proxies `/generate-bayt` requests to the hosted Shaer RunPod endpoint while
building the exact SFT-style prompt (system/user messages) used during training.

## Features

- Builds the canonical Shaer training prompt (system + user message with meter,
  description, era, poet/style, number of verses, previous verses, and guidance).
- Calls the configured RunPod endpoint via `runsync`, forwarding temperature,
  top-p, and max token settings.
- Returns only the generated bayt (صدر + عجز in one line) with the requested
  `sequence_number`, keeping the service stateless and lightweight.
- Runs anywhere FastAPI can run (no GPU/weights on disk) since inference is
  delegated to RunPod.

## API

```
POST /generate-bayt
{
  "poem_meter": "البسيط",
  "poem_description": "قصيدة عن شوق المغترب.",
  "num_verses": 8,
  "sequence_number": 3,
  "previous_verses": ["سطر من البيت الأول", "سطر من البيت الثاني"],
  "poem_era": "العصر الحديث",
  "poet_name": "أسلوب قريب من نزار قباني"
}

Response:
{
  "verse_text": "صدر البيت ... عجز البيت",
  "sequence_number": 3
}
```

## Running locally

```bash
cd services/shaer_service
python -m venv .venv && source .venv/bin/activate
pip install --upgrade pip && pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8002
```

Required environment variables (can live in `.env`):

- `RUNPOD_API_KEY`
- `SHAER_ENDPOINT_ID`

Optional overrides:

- `SHAER_RUNPOD_BASE_URL` (default `https://api.runpod.ai/v2`)
- `SHAER_MAX_NEW_TOKENS`
- `SHAER_TEMPERATURE`
- `SHAER_TOP_P`
- `SHAER_LOG_LEVEL`
- `SHAER_RUNPOD_TIMEOUT`

## Docker

`docker build -t shaer_service . && docker run -p 8002:8000 --env-file ../../.env shaer_service`
